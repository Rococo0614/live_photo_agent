
EventHandles = 
{
    handleEffectEvent = function (this, eventCode)
        print("General effect lazy load")
        if (eventCode == 1) then
            local image2DManager = this:getImage2DManager()
            if (image2DManager) then
                image2DManager:play("lamu02", "processorName01", 0)
            end
        end
        return true
    end,
    handleAnimationEvent = function (this, entityName, clipName, eventCode)
        -- print("GE lazy load: featureTag = ", entityName, " processorName = ", clipName, "eventCode = ", eventCode)      
        return true
    end,
}
